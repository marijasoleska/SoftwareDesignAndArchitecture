package ukim.finki.dians;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiansApplicationTests {

	@Test
	void contextLoads() {
	}

}
