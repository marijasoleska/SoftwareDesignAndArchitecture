package ukim.finki.dians.model;

import java.time.LocalDate;
import java.util.Date;

public class StockData {
    private LocalDate date;
    private double lastTradePrice;
    private double max;
    private double min;
    private double avgPrice;
    private double percentChange;
    private int volume;
    private double turnoverBESTMKD;
    private double totalTurnoverMKD;

    // Getters and Setters
    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getLastTradePrice() {
        return lastTradePrice;
    }

    public void setLastTradePrice(double lastTradePrice) {
        this.lastTradePrice = lastTradePrice;
    }

    public double getMax() {
        return max;
    }

    public void setMax(double max) {
        this.max = max;
    }

    public double getMin() {
        return min;
    }

    public void setMin(double min) {
        this.min = min;
    }

    public double getAvgPrice() {
        return avgPrice;
    }

    public void setAvgPrice(double avgPrice) {
        this.avgPrice = avgPrice;
    }

    public double getPercentChange() {
        return percentChange;
    }

    public void setPercentChange(double percentChange) {
        this.percentChange = percentChange;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }

    public double getTurnoverBESTMKD() {
        return turnoverBESTMKD;
    }

    public void setTurnoverBESTMKD(double turnoverBESTMKD) {
        this.turnoverBESTMKD = turnoverBESTMKD;
    }

    public double getTotalTurnoverMKD() {
        return totalTurnoverMKD;
    }

    public void setTotalTurnoverMKD(double totalTurnoverMKD) {
        this.totalTurnoverMKD = totalTurnoverMKD;
    }
}
