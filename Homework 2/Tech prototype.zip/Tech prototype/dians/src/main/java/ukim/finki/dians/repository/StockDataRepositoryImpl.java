package ukim.finki.dians.repository;

import ukim.finki.dians.model.StockData;
import com.opencsv.bean.CsvToBeanBuilder;
import org.springframework.stereotype.Repository;

import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Repository
public class StockDataRepositoryImpl implements StockDataRepository {
    private static final String DATABASE_PATH = "src/main/resources/Database/";

    @Override
    public List<String> getCompanyNames() {
        try {
            return Files.list(Paths.get(DATABASE_PATH))
                    .filter(Files::isRegularFile)
                    .map(path -> path.getFileName().toString().replace(".csv", ""))
                    .toList();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @Override
    public List<StockData> getStockData(String companyName) {
        try {
            String filePath = DATABASE_PATH + companyName + ".csv";
            return new CsvToBeanBuilder<StockData>(new FileReader(filePath))
                    .withType(StockData.class)
                    .build()
                    .parse();
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
}
