package ukim.finki.dians.repository;

import ukim.finki.dians.model.StockData;

import java.util.List;

public interface StockDataRepository {
    List<String> getCompanyNames(); // Fetch list of company names
    List<StockData> getStockData(String companyName); // Fetch stock data for a given company
}