package ukim.finki.dians.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ukim.finki.dians.model.StockData;
import ukim.finki.dians.service.StockDataService;

import java.time.LocalDate;
import java.util.List;

@Controller
public class StockDataController {

    private final StockDataService stockDataService;

    @Autowired
    public StockDataController(StockDataService stockDataService) {
        this.stockDataService = stockDataService;
    }

    @GetMapping("/")
    public String showMainPage(Model model) {
        model.addAttribute("companies", stockDataService.getCompanyNames());
        return "main";
    }

    @PostMapping("/analyze")
    public String analyze(@RequestParam String company, @RequestParam String fromDate, @RequestParam LocalDate toDate, Model model) {
        List<StockData> stockDataList = stockDataService.getStockDataByDateRange(company, fromDate, String.valueOf(toDate));

        if (stockDataList.isEmpty()) {
            model.addAttribute("error", "No data found for the selected company and date range.");
        } else {
            model.addAttribute("stockDataList", stockDataList);
        }

        return "analysis"; // Ensure this view exists and is correctly set up
    }
}
