package ukim.finki.dians.service;

import org.springframework.stereotype.Service;
import ukim.finki.dians.model.StockData;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class StockDataService {

    private static final String DATABASE_PATH = "src/main/resources/Database/";

    public List<StockData> getStockDataByDateRange(String company, String fromDate, String toDate) {
        List<StockData> stockDataList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy"); // LocalDate format

        try {
            File file = new File(DATABASE_PATH + company + ".csv");
            if (!file.exists()) {
                throw new RuntimeException("File for company " + company + " not found.");
            }

            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            reader.readLine(); // Skip header
            while ((line = reader.readLine()) != null) {
                String[] columns = line.split(",");

                // Parse the date using LocalDate
                String dateStr = columns[0].replace("\"", "").trim();
                LocalDate date = LocalDate.parse(dateStr, formatter);
                LocalDate from = LocalDate.parse(fromDate, formatter);
                LocalDate to = LocalDate.parse(toDate, formatter);

                // If the date is within the specified range, process further
                if (!date.isBefore(from) && !date.isAfter(to)) {
                    StockData stockData = new StockData();
                    stockData.setDate(date);

                    // Clean and convert the price fields (e.g., "9,651.00" to 9651.00)
                    stockData.setLastTradePrice(cleanAndParseDouble(columns[1]));
                    stockData.setMax(cleanAndParseDouble(columns[2]));
                    stockData.setMin(cleanAndParseDouble(columns[3]));
                    stockData.setAvgPrice(cleanAndParseDouble(columns[4]));
                    stockData.setPercentChange(cleanAndParseDouble(columns[5]));

                    // Parse volume and turnover with additional checks
                    stockData.setVolume(parseVolume(columns[6]));
                    stockData.setTurnoverBESTMKD(Double.parseDouble(columns[7].replace("\"", "").trim()));
                    stockData.setTotalTurnoverMKD(Double.parseDouble(columns[8].replace("\"", "").trim()));

                    stockDataList.add(stockData);
                }
            }
            reader.close();
        } catch (Exception e) {
            e.printStackTrace(); // Log the error for debugging
            throw new RuntimeException("Error reading data: " + e.getMessage(), e);
        }

        return stockDataList;
    }

    public List<String> getCompanyNames() {
        List<String> companyNames = new ArrayList<>();

        File directory = new File(DATABASE_PATH);
        if (directory.exists() && directory.isDirectory()) {
            // Get all CSV files in the Database folder
            File[] files = directory.listFiles((dir, name) -> name.endsWith(".csv"));

            if (files != null) {
                for (File file : files) {
                    // Assuming the filename is the company name
                    companyNames.add(file.getName().replace(".csv", ""));
                }
            }
        }
        return companyNames;
    }

    // Utility method to clean and parse a double value from the CSV columns
    private double cleanAndParseDouble(String value) {
        // Remove extra spaces and quotes, and replace commas if present
        value = value.replace("\"", "").replace(",", "").trim();
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return 0.0; // Return 0 if parsing fails (handle gracefully)
        }
    }

    // Utility method to safely parse volume as an integer
    private int parseVolume(String value) {
        value = value.replace("\"", "").trim();
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0; // Return 0 if parsing fails
        }
    }
}
