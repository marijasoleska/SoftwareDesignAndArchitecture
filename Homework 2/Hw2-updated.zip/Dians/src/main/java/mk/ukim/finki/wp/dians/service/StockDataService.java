package mk.ukim.finki.wp.dians.service;


import mk.ukim.finki.wp.dians.model.StockObservation;

import java.util.List;

public interface StockDataService {

    List<StockObservation> getStockDataByDateRange(String company, String fromDate, String toDate);
    List<String> getCompanyNames();
}

