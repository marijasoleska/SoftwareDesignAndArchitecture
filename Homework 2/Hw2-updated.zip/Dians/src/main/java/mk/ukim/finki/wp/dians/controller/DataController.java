package mk.ukim.finki.wp.dians.controller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import mk.ukim.finki.wp.dians.model.StockObservation;
import mk.ukim.finki.wp.dians.service.impl.StockDataService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping({"/data","/"})
public class DataController {

    private final StockDataService stockService;

    public DataController(StockDataService stockService) {
        this.stockService = stockService;
    }

    @GetMapping
    public String getDataPage(HttpServletRequest request,
                              @RequestParam(required = false) String company,
                              @RequestParam(required = false) String dateFrom,
                              @RequestParam(required = false) String dateTo,
                              Model model) {
        model.addAttribute("companies", stockService.getCompanyNames());
        List<StockObservation> observations = (List<StockObservation>) request.getSession().getAttribute("observationsPresent");

        if (observations != null) {
            model.addAttribute("observations", observations);
        }
        if (dateFrom != null && dateTo != null && company != null) {
            model.addAttribute("dateFrom", dateFrom);
            model.addAttribute("company", company);
            model.addAttribute("dateTo", dateTo);
        }

        return "mainPage"; // Redirect to the main page template
    }

    @PostMapping
    public String filterData(
            HttpServletRequest request,
            @RequestParam String company,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") String dateFrom,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") String dateTo
    ) {
        List<StockObservation> observationList = stockService.getStockDataByDateRange(company, dateFrom, dateTo);
        HttpSession session = request.getSession();

        session.setAttribute("observationsPresent", observationList);

        return String.format("redirect:/data/analysis"); // Redirect to the analysis page
    }
    @GetMapping("/analysis")
    public String viewAnalysisPage(HttpServletRequest request, Model model) {
        List<StockObservation> observations = (List<StockObservation>) request.getSession().getAttribute("observationsPresent");
        model.addAttribute("observations", observations);
        return "analysisPage"; // Render the analysis page
    }
}
