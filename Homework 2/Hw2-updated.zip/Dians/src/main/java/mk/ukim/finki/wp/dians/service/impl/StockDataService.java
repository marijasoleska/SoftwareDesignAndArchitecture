package mk.ukim.finki.wp.dians.service.impl;

import org.springframework.stereotype.Service;
import mk.ukim.finki.wp.dians.model.StockObservation;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class StockDataService {

    private static final String DATABASE_PATH = "src/main/resources/data/";

    public List<StockObservation> getStockDataByDateRange(String company, String fromDate, String toDate) {
        List<StockObservation> stockDataList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

        try (BufferedReader reader = new BufferedReader(new FileReader(DATABASE_PATH + company + ".csv"))) {
            String line;
            reader.readLine(); // Skip the header row

            LocalDate from = LocalDate.parse(fromDate, formatter);
            LocalDate to = LocalDate.parse(toDate, formatter);

            while ((line = reader.readLine()) != null) {
                String[] columns = line.split(",");
                LocalDate date = LocalDate.parse(columns[0].replace("\"", "").trim(), formatter);

                if (!date.isBefore(from) && !date.isAfter(to)) {
                    StockObservation stockData = parseStockData(columns, date);
                    stockDataList.add(stockData);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading file: " + e.getMessage(), e);
        }

        return stockDataList;
    }

    public List<String> getCompanyNames() {
        List<String> companyNames = new ArrayList<>();
        File directory = new File(DATABASE_PATH);

        if (directory.exists() && directory.isDirectory()) {
            File[] files = directory.listFiles((dir, name) -> name.endsWith(".csv"));

            if (files != null) {
                for (File file : files) {
                    companyNames.add(file.getName().replace(".csv", ""));
                }
            }
        }

        return companyNames;
    }

    private StockObservation parseStockData(String[] columns, LocalDate date) {
        StockObservation stockData = new StockObservation();
        stockData.setDate(date);
        stockData.setLastTradePrice(cleanAndParseDouble(columns[1]));
        stockData.setMax(cleanAndParseDouble(columns[2]));
        stockData.setMin(cleanAndParseDouble(columns[3]));
        stockData.setAvgPrice(cleanAndParseDouble(columns[4]));
        stockData.setPercentChange(cleanAndParseDouble(columns[5]));
        stockData.setVolume(parseVolume(columns[6]));
        stockData.setTurnoverBESTMKD(cleanAndParseDouble(columns[7]));
        stockData.setTotalTurnoverMKD(cleanAndParseDouble(columns[8]));

        return stockData;
    }

    private double cleanAndParseDouble(String value) {
        value = value.replace("\"", "").replace(",", "").trim();
        try {
            return Double.parseDouble(value);
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private int parseVolume(String value) {
        value = value.replace("\"", "").trim();
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
