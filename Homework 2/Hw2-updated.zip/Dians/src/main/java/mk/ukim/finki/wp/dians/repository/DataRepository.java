package mk.ukim.finki.wp.dians.repository;


import com.opencsv.bean.CsvToBeanBuilder;
import mk.ukim.finki.wp.dians.model.StockObservation;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import jakarta.annotation.PostConstruct;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.*;

@Repository
public class DataRepository {

    @Value("${database.data.path}")
    private String dbPath;

    private final Map<String, List<StockObservation>> companies = new HashMap<>();

    @PostConstruct
    public void loadStockData() {
        try {
            Files.list(Paths.get(dbPath))
                    .filter(Files::isRegularFile)
                    .forEach(this::processFile);
        } catch (Exception e) {
            throw new RuntimeException("Error loading stock data files", e);
        }
    }

    private void processFile(Path path) {
        try {
            String companyName = path.getFileName().toString().replace(".csv", "");
            List<StockObservation> stockData = new CsvToBeanBuilder<StockObservation>(new FileReader(path.toFile()))
                    .withType(StockObservation.class)
                    .build()
                    .parse();
            companies.put(companyName, stockData);
        } catch (Exception e) {
            System.err.println("Error processing file: " + path.getFileName());
            e.printStackTrace();
        }
    }

    public List<String> getCompanyNames() {
        return new ArrayList<>(companies.keySet());
    }

    public List<StockObservation> getStockData(String companyName) {
        return companies.getOrDefault(companyName, new ArrayList<>());
    }

    public List<StockObservation> getRecordsFromTo(String companyName, LocalDate from, LocalDate to) {
        return companies.getOrDefault(companyName, Collections.emptyList())
                .stream()
                .filter(record -> !record.getDate().isBefore(from) && !record.getDate().isAfter(to))
                .toList();
    }
}
