package mk.ukim.finki.wp.dians.retrieve;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.dians.service.DatabaseRefreshService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class DataRetrieve {

    @Value("${database.update.script}")
    private String scriptName;

    private final DatabaseRefreshService refreshService;

    public DataRetrieve(DatabaseRefreshService refreshService) {
        this.refreshService = refreshService;
    }

    @Scheduled(cron = "0 10 10 * * *")
    @PostConstruct
    public void updateDatabase() throws InterruptedException {
        String scriptPath = "src/main/resources/" + scriptName;

        String[] command = {"python", scriptPath};
        ProcessBuilder processBuilder = new ProcessBuilder(command);

        try {
            Process process = processBuilder.start();
            process.waitFor();
            refreshService.refreshDatabase();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}

