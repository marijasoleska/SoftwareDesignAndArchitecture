package mk.ukim.finki.wp.dians.service.impl;


import mk.ukim.finki.wp.dians.service.DatabaseRefreshService;
import org.springframework.stereotype.Service;
import mk.ukim.finki.wp.dians.repository.DataRepository;

@Service
public class DatabaseRefresh implements DatabaseRefreshService {

    private final DataRepository stockDataRepository;
    public DatabaseRefresh(DataRepository stockDataRepository) {
        this.stockDataRepository = stockDataRepository;
    }

    @Override
    public void refreshDatabase() {
        // Logic for refreshing the database
        // Since the repository fetches data dynamically, we don't have a direct in-memory refresh.
        // This method can be used for cleanup, preloading, or recalculation tasks.

        // Example (optional): Preloading all company data into memory (if needed for optimization)
        stockDataRepository.getCompanyNames().forEach(company -> {
            try {
                stockDataRepository.getStockData(company);
                System.out.println("Preloaded data for company: " + company);
            } catch (Exception e) {
                System.err.println("Error preloading data for company: " + company + " - " + e.getMessage());
            }
        });

        System.out.println("Database refresh completed successfully.");
    }
}

