package mk.ukim.finki.wp.dians.service;


public interface DatabaseRefreshService {
    void refreshDatabase();
}

