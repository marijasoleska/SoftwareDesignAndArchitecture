package mk.ukim.finki.wp.dians.model;

import lombok.Data;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;

@Data
public class StockObservation implements Comparable<StockObservation> {
    private LocalDate date;
    private Double lastTradePrice;
    private Double max;
    private Double min;
    private Double avgPrice;
    private Double percentChange;
    private Long volume;
    private Double turnoverBestMKD;
    private Double totalTurnoverMKD;

    private static final NumberFormat FORMAT = NumberFormat.getInstance(Locale.GERMAN);

    @Override
    public int compareTo(StockObservation o) {
        return date.compareTo(o.date);
    }

    public String getFormattedNumber(Number number) {
        return number == null ? "" : FORMAT.format(number);
    }

    @Override
    public String toString() {
        return String.format(
                "StockObservation[date=%s, lastTradePrice=%s, max=%s, min=%s, avgPrice=%s, percentChange=%s, volume=%s, turnoverBestMKD=%s, totalTurnoverMKD=%s]",
                date, getFormattedNumber(lastTradePrice), getFormattedNumber(max), getFormattedNumber(min),
                getFormattedNumber(avgPrice), getFormattedNumber(percentChange), getFormattedNumber(volume),
                getFormattedNumber(turnoverBestMKD), getFormattedNumber(totalTurnoverMKD));
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public double getLastTradePrice() {
        return lastTradePrice;
    }

    public void setLastTradePrice(double lastTradePrice) {
        this.lastTradePrice = lastTradePrice;
    }

    public double getMax() {
        return max;
    }

    public void setMax(double max) {
        this.max = max;
    }

    public double getMin() {
        return min;
    }

    public void setMin(double min) {
        this.min = min;
    }

    public double getAvgPrice() {
        return avgPrice;
    }

    public void setAvgPrice(double avgPrice) {
        this.avgPrice = avgPrice;
    }

    public double getPercentChange() {
        return percentChange;
    }

    public void setPercentChange(double percentChange) {
        this.percentChange = percentChange;
    }

    public long getVolume() {
        return volume;
    }

    public void setVolume(long volume) {
        this.volume = volume;
    }

    public double getTurnoverBESTMKD() {
        return turnoverBestMKD;
    }

    public void setTurnoverBESTMKD(double turnoverBESTMKD) {
        this.turnoverBestMKD = turnoverBESTMKD;
    }

    public double getTotalTurnoverMKD() {
        return totalTurnoverMKD;
    }

    public void setTotalTurnoverMKD(double totalTurnoverMKD) {
        this.totalTurnoverMKD = totalTurnoverMKD;
    }
}
